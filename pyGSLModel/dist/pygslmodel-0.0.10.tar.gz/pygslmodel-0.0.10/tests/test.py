# Downloading pruned model
import sys
print(sys.prefix)