# Downloading pruned model
from pyGSLModel import download_GSL_model

model = download_GSL_model()